import { GoogleGenAI, Type, Schema } from "@google/genai";
import { AnalysisResult } from "../types";

// Initialize Gemini
// CRITICAL: The API key must be process.env.API_KEY
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const analysisSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    environment: {
      type: Type.NUMBER,
      description: "Score from -10 (very bad) to +10 (very good) for Environmental impact.",
    },
    social: {
      type: Type.NUMBER,
      description: "Score from -10 to +10 for Social impact.",
    },
    governance: {
      type: Type.NUMBER,
      description: "Score from -10 to +10 for Governance impact.",
    },
    category: {
      type: Type.STRING,
      description: "A short category tag for this activity (e.g., 'Transport', 'Achats', 'Énergie').",
    },
    taxonomyAlignment: {
      type: Type.STRING,
      description: "Is this activity aligned with EU Taxonomy? Options: 'Aligné', 'Partiellement aligné', 'Non aligné', 'Neutre'.",
    },
    euTaxonomyObjective: {
      type: Type.STRING,
      description: "Which EU Taxonomy objective does this relate to? (e.g., 'Atténuation du changement climatique', 'Économie circulaire', 'Biodiversité', etc.)",
    },
    feedback: {
      type: Type.STRING,
      description: "A brief, actionable feedback or explanation in French about why this score was given.",
    },
  },
  required: ["environment", "social", "governance", "category", "taxonomyAlignment", "euTaxonomyObjective", "feedback"],
};

export const analyzeESGAction = async (description: string, type: 'professional' | 'personal'): Promise<AnalysisResult> => {
  const model = "gemini-3-flash-preview";

  const prompt = `
    Agis comme un expert en comptabilité extra-financière et en Taxonomie Européenne.
    Analyse l'activité suivante (Type: ${type}): "${description}".
    
    Ton objectif est de traduire cette activité en scores ESG quantifiables.
    Considère l'impact sur l'Environnement (E), le Social (S) et la Gouvernance (G).
    
    Si l'activité est un achat, considère le cycle de vie du produit.
    Si c'est une décision de gestion, considère l'impact sur les employés et l'éthique.
    
    Réponds EXCLUSIVEMENT avec un objet JSON respectant le schéma fourni.
  `;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: analysisSchema,
        systemInstruction: "Tu es un auditeur ESG expert. Sois précis, critique et constructif.",
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");

    const json = JSON.parse(text);

    return {
      scores: {
        environment: json.environment,
        social: json.social,
        governance: json.governance,
      },
      category: json.category,
      taxonomyAlignment: json.taxonomyAlignment,
      euTaxonomyObjective: json.euTaxonomyObjective,
      feedback: json.feedback,
    };
  } catch (error) {
    console.error("Error analyzing ESG action:", error);
    // Return a neutral fallback in case of error to prevent app crash
    return {
      scores: { environment: 0, social: 0, governance: 0 },
      category: "Erreur",
      taxonomyAlignment: "Inconnu",
      euTaxonomyObjective: "Non classifié",
      feedback: "Impossible d'analyser cette entrée pour le moment.",
    };
  }
};
