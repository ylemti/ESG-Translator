import React from 'react';
import { Entry } from '../types';
import { Leaf, Users, Building, AlertCircle, CheckCircle } from 'lucide-react';

interface Props {
  entry: Entry;
}

export const AnalysisCard: React.FC<Props> = ({ entry }) => {
  if (entry.loading) {
    return (
      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 animate-pulse">
        <div className="h-4 bg-slate-200 rounded w-3/4 mb-4"></div>
        <div className="h-4 bg-slate-200 rounded w-1/2"></div>
      </div>
    );
  }

  if (!entry.analysis) return null;

  const { scores, taxonomyAlignment, feedback, euTaxonomyObjective } = entry.analysis;

  const getAlignmentColor = (align: string) => {
    switch (align.toLowerCase()) {
      case 'aligné': return 'text-emerald-600 bg-emerald-50 border-emerald-200';
      case 'partiellement aligné': return 'text-amber-600 bg-amber-50 border-amber-200';
      case 'non aligné': return 'text-red-600 bg-red-50 border-red-200';
      default: return 'text-slate-600 bg-slate-50 border-slate-200';
    }
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow duration-200">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="font-semibold text-slate-800 text-lg">{entry.description}</h3>
          <p className="text-sm text-slate-500">{new Date(entry.timestamp).toLocaleDateString('fr-FR')} • {entry.type === 'professional' ? 'Pro' : 'Perso'}</p>
        </div>
        <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getAlignmentColor(taxonomyAlignment)}`}>
          {taxonomyAlignment}
        </span>
      </div>

      <div className="grid grid-cols-3 gap-4 mb-4">
        <div className="flex flex-col items-center p-2 rounded-lg bg-emerald-50/50">
          <Leaf className="w-5 h-5 text-emerald-600 mb-1" />
          <span className="text-xs text-slate-500">Env</span>
          <span className={`font-bold ${scores.environment >= 0 ? 'text-emerald-700' : 'text-red-600'}`}>
            {scores.environment > 0 ? '+' : ''}{scores.environment}
          </span>
        </div>
        <div className="flex flex-col items-center p-2 rounded-lg bg-blue-50/50">
          <Users className="w-5 h-5 text-blue-600 mb-1" />
          <span className="text-xs text-slate-500">Soc</span>
          <span className={`font-bold ${scores.social >= 0 ? 'text-blue-700' : 'text-red-600'}`}>
            {scores.social > 0 ? '+' : ''}{scores.social}
          </span>
        </div>
        <div className="flex flex-col items-center p-2 rounded-lg bg-indigo-50/50">
          <Building className="w-5 h-5 text-indigo-600 mb-1" />
          <span className="text-xs text-slate-500">Gouv</span>
          <span className={`font-bold ${scores.governance >= 0 ? 'text-indigo-700' : 'text-red-600'}`}>
            {scores.governance > 0 ? '+' : ''}{scores.governance}
          </span>
        </div>
      </div>

      <div className="space-y-2">
         <div className="flex items-start gap-2 text-sm text-slate-600 bg-slate-50 p-3 rounded-md">
            <AlertCircle className="w-4 h-4 text-slate-400 mt-0.5 flex-shrink-0" />
            <p>{feedback}</p>
         </div>
         <div className="flex items-center gap-2 text-xs text-slate-500 mt-2">
            <CheckCircle className="w-3 h-3" />
            <span>Objectif: {euTaxonomyObjective}</span>
         </div>
      </div>
    </div>
  );
};
