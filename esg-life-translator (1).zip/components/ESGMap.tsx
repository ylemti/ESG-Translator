import React from 'react';
import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Legend, Tooltip } from 'recharts';
import { ESGScores } from '../types';

interface Props {
  totalScores: ESGScores;
  entryCount: number;
}

export const ESGMap: React.FC<Props> = ({ totalScores, entryCount }) => {
  // Normalize scores to avoid negative values breaking the radar chart visuals easily, 
  // or use a domain that allows negatives. 
  // Strategy: Map -50 to +50 range to 0-100 for visualization, or just clamp.
  // Let's assume we want to show raw cumulative impact.
  
  // Actually, let's show an average score per dimension to keep the chart readable -10 to 10 scale.
  const avgScores = entryCount > 0 ? {
    environment: parseFloat((totalScores.environment / entryCount).toFixed(1)),
    social: parseFloat((totalScores.social / entryCount).toFixed(1)),
    governance: parseFloat((totalScores.governance / entryCount).toFixed(1)),
  } : { environment: 0, social: 0, governance: 0 };

  const data = [
    { subject: 'Environnement', A: avgScores.environment, fullMark: 10 },
    { subject: 'Social', A: avgScores.social, fullMark: 10 },
    { subject: 'Gouvernance', A: avgScores.governance, fullMark: 10 },
  ];

  // Custom tooltip to handle positive/negative context
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-slate-200 shadow-lg rounded-lg text-sm">
          <p className="font-semibold mb-1">{label}</p>
          <p className={payload[0].value >= 0 ? "text-emerald-600" : "text-red-500"}>
            Score Moyen: {payload[0].value}
          </p>
          <p className="text-slate-400 text-xs">Échelle: -10 à +10</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="w-full h-80 bg-white p-4 rounded-2xl shadow-sm border border-slate-100 flex flex-col items-center justify-center relative">
      <h3 className="absolute top-4 left-6 font-semibold text-slate-700">Votre Map ESG (Moyenne)</h3>
      
      {entryCount === 0 ? (
         <div className="text-slate-400 text-sm italic">Ajoutez des activités pour voir votre carte.</div>
      ) : (
        <ResponsiveContainer width="100%" height="100%">
          <RadarChart cx="50%" cy="50%" outerRadius="70%" data={data}>
            <PolarGrid stroke="#e2e8f0" />
            <PolarAngleAxis dataKey="subject" tick={{ fill: '#64748b', fontSize: 12, fontWeight: 500 }} />
            <PolarRadiusAxis angle={30} domain={[-10, 10]} tick={false} axisLine={false} />
            <Radar
              name="ESG"
              dataKey="A"
              stroke="#0ea5e9"
              strokeWidth={3}
              fill="#0ea5e9"
              fillOpacity={0.2}
            />
            <Tooltip content={<CustomTooltip />} />
          </RadarChart>
        </ResponsiveContainer>
      )}
    </div>
  );
};
