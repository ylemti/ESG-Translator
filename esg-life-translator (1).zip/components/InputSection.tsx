import React, { useState } from 'react';
import { Send, Briefcase, User, Sparkles } from 'lucide-react';

interface Props {
  onAnalyze: (text: string, type: 'professional' | 'personal') => void;
  isAnalyzing: boolean;
}

export const InputSection: React.FC<Props> = ({ onAnalyze, isAnalyzing }) => {
  const [text, setText] = useState('');
  const [type, setType] = useState<'professional' | 'personal'>('professional');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim()) {
      onAnalyze(text, type);
      setText('');
    }
  };

  return (
    <div className="bg-white p-6 rounded-2xl shadow-lg border border-slate-100 mb-8">
      <div className="mb-4">
        <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-amber-500" />
          Traducteur d'Impact
        </h2>
        <p className="text-slate-500 text-sm">Décrivez une dépense, une action ou une décision pour obtenir son score ESG.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="flex gap-4 p-1 bg-slate-100 rounded-lg w-fit">
          <button
            type="button"
            onClick={() => setType('professional')}
            className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all ${
              type === 'professional' 
                ? 'bg-white text-emerald-700 shadow-sm' 
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            <Briefcase className="w-4 h-4" />
            Professionnel
          </button>
          <button
            type="button"
            onClick={() => setType('personal')}
            className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all ${
              type === 'personal' 
                ? 'bg-white text-blue-700 shadow-sm' 
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            <User className="w-4 h-4" />
            Personnel
          </button>
        </div>

        <div className="relative">
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={type === 'professional' 
              ? "Ex: Achat de 5 PC portables reconditionnés pour l'équipe commerciale..." 
              : "Ex: Installation d'une pompe à chaleur à la maison..."}
            className="w-full p-4 pr-12 rounded-xl bg-slate-50 border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all resize-none h-24 text-slate-700"
            disabled={isAnalyzing}
          />
          <button
            type="submit"
            disabled={!text.trim() || isAnalyzing}
            className="absolute bottom-3 right-3 p-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {isAnalyzing ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <Send className="w-5 h-5" />
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
