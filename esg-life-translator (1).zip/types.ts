export interface ESGScores {
  environment: number;
  social: number;
  governance: number;
}

export interface AnalysisResult {
  scores: ESGScores;
  category: string;
  taxonomyAlignment: string; // e.g., "Aligned", "Not Aligned", "Neutral"
  feedback: string;
  euTaxonomyObjective: string; // e.g., "Climate Change Mitigation", "Circular Economy"
}

export interface Entry {
  id: string;
  description: string;
  timestamp: Date;
  amount?: number; // Optional financial amount
  type: 'professional' | 'personal';
  analysis: AnalysisResult | null;
  loading: boolean;
}

export type TabView = 'dashboard' | 'history' | 'settings';

export interface ChartDataPoint {
  subject: string;
  A: number;
  fullMark: number;
}